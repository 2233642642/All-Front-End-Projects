document.addEventListener('DOMContentLoaded', () => {
    const movableObject = document.getElementById('movable-object');
    let direction = 1;
    let position = 0;

    function animateObject() {
        position += direction;
        if (position > 300 || position < -300) {
            direction *= -1;
        }
        movableObject.style.transform = `translate(-50%, -50%) translateX(${position}px)`;
        requestAnimationFrame(animateObject);
    }

    animateObject();
});
